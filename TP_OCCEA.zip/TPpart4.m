%Nom et Pr�noms : 
%AGBENDA Essosimna Princesse
%Taha Ismail Hassane

clear all;
close all;
clc; % Code pour n�toyer la fenetre de commande lors d'une vouvelle op�ration

%Etude dans le domaine fr�quentiel
%6.1.1 Cas d'une note
fs = 8000; %e
d = 2; % dur�e en seconde
n_note = 69;

%6.1.2 Ecoutous createnote
x = createnote(d,n_note,fs);
%soundsc(x) %commande pour �couter la fonction createnote.


[X,f]=myFFT(x,fs);

Vabs = abs(X).^2;

plot(f, Vabs);


%6.1.3 Calcul sur papier de la transform�ee de fourier et de son module
%Le r�sultat du mpdule de la transform�e de fourier de de x(t) est est 1/4*(dirac (f-fo)+dirac(f+fo))
% Sa repr�sentation correspond au r�sultat observ� sue la repr�sentation
% graphique.


%6.1.4 La resolution en fr�quence est delta f = fs/N = 1/d 
% Dans notre cas d = 2s donc la resolution est �gale � 0.5 Hz


%la TFD ne pourra pas distinguer deux fr�quences qui sont plus proches que 0,5Hz. 
%Par cons�quent, les notes qui ont une fr�quence proche ou inf�rieure � 0,5 Hz pourront �tre mal r�solues 
%ou pas du tout observables sur la TFD, tandis que les notes dont la fr�quence est plus �lev�e que 0,5 Hz 
%seront mieux r�solues et visibles sur la TFD.

%Dans le tableau SEULE LA NOTE 69 � 440 hz sera �cout�e car la note
%suivante est � une fr�quence supp�rieur � 0.5 Hz

%6.1.5 Sur le module on peut voir que le dirac est retard� de fo donc on a
%un dirac sur le spectre � f=fo = 440hz

%6.2 Cas d'une m�lodie
%6.2.1
dvect = [1,1,1,1]
vect = [69, 40, 80, 60] %LES Fr�quences sont respectivement 440, 82.41, 830.61, 261.63
m = createmelody(dvect,vect,fs)
%soundsc(m)
[M,f]=myFFT(m,fs);
Mabs = abs(M).^2;

plot(f, Mabs) % Sur le spectre on observe effectivement les fr�quences s�lectionnee plus haut de part et d'autre de la fr�quence 0 
%Le module au carr� de la transform�e de Fourier repr�sente la puissance du signal sonore � chaque fr�quence. Ainsi, pour une note de musique donn�e, la transform�e de Fourier aura une forte amplitude � la fr�quence correspondante � cette note. Le module au carr� de la transform�e de Fourier aura donc une forte valeur � cette m�me fr�quence.



