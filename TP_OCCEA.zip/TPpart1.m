%Nom et Pr�noms : 
%AGBENDA Essosimna Princesse
%Taha Ismail Hassane


%PARTIE 3 :Initiation � MATLAB
% 1) 

clear all;
close all;
clc; % Code pour n�toyer la fenetre de commande lors d'une vouvelle op�ration 

% 2) D�termination de la valeur de N

%Entr�es des constantes
 fo = 300; %fr�quence fondamentale en Hz
 d = 2;  % Dur�e du signal en s
 Fs = 8000; %Fr�quence d'�chantillonage en Hz
 
 N = d*Fs % Nombre d'�chantillons
 
 % 3) Construction du vecteur t de taille N
 % tn = n*Ts donc nous allons d�finir le vecteur n appartenant a
 % l'intervalle allant de 0 � N-1 et le multiplier par Ts
 
 n= 0:1:(N-1);
 Ts = 1/Fs;
 t = n*Ts;
% A pres l'ex�cution du programme on a obtenu comme premiere valeur de t 0.4375  et derniere valeur 1.9999

% 4)Construction du signal x contenant les diff�rentes valeurs xn

x = sin(2*pi*fo*t);

%  L a premiere valeur de x est : x0 = sin(0) = 0.0000    
% Le x1 est 0.5878  et le x(N-1) est -0.5878

% 5) Ecoutons le signal
%soundsc(x);
% Le son est grave
% Avec fo = 300 hz le son est beaucoup pls grave
% Avec fo = 1000hz le signal est tres aigu
%nous tirons la conclusion que plus la fr�quence de la fondamentale est est
%�lev�e plus le son est aigue.

%6) Afficher avec la commande plot le signal �chantillonn� xn en fonction du temps sur l�intervalle
%[0, 4T0]
To = 1/fo;
NTo = 4*To*Fs;
plot(t(1:NTo), x(1:NTo))







