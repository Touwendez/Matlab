

R = 1.44;
L= 5.6e-4;
J= 1.29e-4;
f=7.2e-5;
Ke = 0.10;


K= (Ke)/(R*f+Ke^2)
Toe = L/R;
Tom = (R*J)/(R*f + Ke^2)

G = zpk([], [(-1/Toe) (-1/Tom)], K/(Toe*Tom))

pole(G)


% Reponse question 4
figure % creation de la fonction figure
 
% dividion de la figure en 2 sous trac�s
%subplot(2,1,1) % Dessin dans la premiere ligne
%step(G) %  reponse indicielle a un �echelon unitaire de tension
 
%subplot(2,1,2) % Dessin dans la deuxieme ligne sous la premiere
%bode(G) %le diagramme de Bode



% Question 5
Kp = 10;
Kw = 10/(3000 * 2*3.14/60)
 
% Question 6
% Fonction de transfert en BO
Fbo = Kp*Kw*G
% Fonction de transfert en BF
Fbf = feedback(Kp*G,Kw)
 
% Question 7
% trace des reponses indicielles en BO ET BF
figure
subplot(2,1,1)
step(Fbo)
 
subplot(2,1,2)
step(Fbf)
 
%question 8
%les diagrammes de Bode, Black et Nyquist du syst`eme en boucle ouverte
%figure
%subplot(4,1,1:2)
%bode(Fbo)
 
%subplot(4,1,3)
%nichols(Fbo)
 
%subplot(4,1,4)
%nyquist(Fbo)


[Gm,Pm,Wcg,Wcp] = margin(Fbo)%  les marges de stabilit�e du systeme
 
figure
%question 9
hold on
for Kp =[10,100,1000]
    Fbf = feedback(Kp*G,Kw)
    step(Fbf)    
end
hold off


Ko=50*(360/(2*pi)) ;   %V.deg-1
phim = (pi)/3 % RADIANT CORRESpondant � 60 degr�

a = (1+sin(phim))/(1-sin(phim))
W=160
T= 1/(sqrt(a)*W);


%kP = 10;

%K = zpk([-1/(a*T)], [-1/T], kP)
KT = zpk([-1/(a*T)], [-1/T],1)

%figure
%subplot(2,1,1:2)
%bode(K)

% D�finisson la fontion 1/p
I = tf([1],[1 0])
Qbf = feedback(G*I,Ko)
Qbo = G*I*Ko

figure
subplot(2,1,1)
step(Qbf)

subplot(2,1,2)
nichols(Qbo)




%%%%%%%%%%%%12


%arg(eval(K, W))
Ko=50*(360/(2*pi))
phasedeK = 60-180- 180/pi*(angle(evalfr(G, j*W)) + angle(evalfr(I, j*W)))

phim = phasedeK % RADIANT

a = (1+sin(phim))/(1-sin(phim))

T= 1/(sqrt(a)*W);

KT = zpk([-1/(a*T)], [-1/T],1)

%phasedeK = 44.7853

%Kpp = 1/(abs(evalfr(G, jW))*A)

aa = abs(evalfr(G, j*W))*abs(evalfr(I, j*W))*(abs(evalfr(KT, j*W)))*(Ko)

Kpp = aa^(-1)  %Kpp = 0.0656


K = zpk([-1/(a*T)], [-1/T], Kpp)

YGbo = K*G*I*Ko
YGbf =feedback(K*G*I,Ko)

figure
subplot(2,1,1)
nichols(YGbo)

subplot(2,1,2)
step(YGbf)











 