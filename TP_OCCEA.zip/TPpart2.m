%Nom et Pr�noms : 
%AGBENDA Essosimna Princesse
%Taha Ismail Hassane

clear all;
close all;
clc; % Code pour n�toyer la fenetre de commande lors d'une vouvelle op�ration

% PARTIE 4 : Etude dans le domaine temporel
%Nous allons maintenant �tudier les propri�t�s de notre signal : p�riodicit�, �nergie, puissance moyenne.
%D�fintion des valeurs : 
Fs = 8000;  % Fr�quence d'�chantillonage en Hz 
d = 1000; % en seconde
fo = 800; % fr�quence fondamentale en Hz 
N = d*Fs; % Nombre d'�chantillons
 
 
 
 
 %2) D�terminons la p�riodicit� du signal .  
 n= 0:1:(N-1);
 Ts = 1/Fs;
 t = n*Ts;
 
 x = sin(2*pi*fo*t);
 
 Mo = 1/fo;
NMo = 2*Mo*Fs;  % Numero de l'�chantillons correspondant � deux p�riodes
plot(t(1:NMo), x(1:NMo)) % Visualisation de deux p�riodes
% On observe que la courbe est bien p�riodique. Sa p�riode fondamentale est  Mo = 1/fo
% Mo = 0.0013
 
 % Calcul de la distance euclidienne entre deux p�riodes du signal
 NP = Mo*Fs; % Numero de l'�chantillons correspondant � une p�riode
 Ecl = sum((x(1:NP)-x((NP+1):NMo)).^2); % Carr� de la distance euclidienne
 %  Ecl =  1.9196e-30 . C'est pratiquement �gale � 0.
 
 % 3 Calculer de l��nergie totale et la puissance moyenne totale du signal x(t)
 
 %L'�nergie est egale a l'int�grale du carr� du sinus. C'est l'aire sous la
 %courve d�finue par le carr� du sinus : donc on en d�duit que l'�nergie de
 %- l'infin � + l'infini est �gale � + l'infini.
 
 % La puissance moyenne obtenu sur une p�riode T0 par calcul est egale � 0.5 W
 
 %4) En synth�tisant un signal de d = 1000 secondes , �valuons sous l��nergie totale Ex, la puissance moyenne totale Px du signal xn. 

 E = sum(x.^2);
 % On obtient E =  4.0000e+06 J .
 
 P = sum(x(1:NP).^2)/NP;
 % On obtient P = 0.5
 
 % Le signal possede une �nergie infinie et garde la meme puissance moyenne peut importe la dur�e du signal.
 %On deduit de ces r�sultats que notre signal est � �nergie infini.
 
 
 
 
 
 
 
 
 
 
 
 
 
 

