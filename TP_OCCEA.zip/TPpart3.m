%Nom et Pr�noms : 
%AGBENDA Essosimna Princesse
%Taha Ismail Hassane

clear all;
close all;
clc; % Code pour n�toyer la fenetre de commande lors d'une vouvelle op�ration


 % PARTIE 5 : Synth�se d�une note et d�une m�lodie
 
 fo = 440 % fr�quence fondamentale en Hz 

 
 
 x = sin(2*pi*fo*t);
 
 Mo = 1/fo;
NMo = 2*Mo*Fs;

% 1) Cre�ons une fonction createnote.m
 function A = createnote(d,note,Fs)
 N = d*Fs;
 n= 0:1:(N-1);
 Ts = 1/Fs;
 t = n*Ts;
 fnote = 440*2^((note-69)/12);
 x = sin(2*pi*fnote*t) 
 
 end
