function x = createmelody(dvect,vect,fs)
  x = [] % on creer un vecteur vide
  for i = 1:length(dvect) % pour chaque note
    x = cat(2,x, createnote(dvect(i),vect(i),fs)); % concat de la melody existante avec la nouvelle note
  end
end
