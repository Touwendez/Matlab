function [spectrum,f] = myFFT (signal, fs)

pas = 1/fs;
N=length(signal);

f = [-fs/2:fs/(N-1):fs/2];
s=reshape(signal,1,N);
w=hamming(N);
ss=s.*w';
ss=ss/mean(w);
spectrum=pas*fftshift(fft(ss));
end
