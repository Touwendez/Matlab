function signal = myFFTinv (spectrum, fs)
  pas = 1/fs;
  N=max(size(spectrum));
  s=reshape(spectrum,1,N);
  w=hamming(N);
  s=s/(pas)*mean(w);
  signal=real(ifft(ifftshift(s))./w');
end

