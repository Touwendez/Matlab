%Nom et Pr�noms : 
%AGBENDA Essosimna Princesse
%Taha Ismail Hassane

clear all;
close all;
clc; % Code pour n�toyer la fenetre de commande lors d'une vouvelle op�ration

fs = 8000; %e
%d = 2; % dur�e en seconde
%n_note = 69;

% 7 . Filtrage et s�paration de sources
% 7.1 

dvect = [1,1]
vect = [69, 80] %LES Fr�quences sont respectivement 440, 830.61
m = createmelody(dvect,vect,fs);
%soundsc(m)
[M,f]=myFFT(m,fs);
Mabs = abs(M).^2;
plot(f, Mabs);

% on propose comme fr�quence de coupure : 600 hz
fc = 600;
% 7.2 Cr�eons un vecteur HLP et un vecteur HHP correspondant aux fonctions de transfert du filtre passe-bas et passe-haut id�aux
Hlp = abs(f)<=600; % filtre pass bas de fr�quence de coupure 600 hz
Hhp  = abs (f)>= 600; % filtre pass haut de fr�quence de coupure 600 hz



%7.3 
Sk1 = myFFTinv (M.*Hlp, fs);
Sk2 = myFFTinv (M.*Hhp, fs);
figure
subplot(3,1,1)
plot(f, Mabs)
subplot(3,1,2)
plot(Sk1)

subplot(3,1,3)
plot(Sk2)
% Apres filtrage on bserve unique les simus des fonctions � leurs
% fr�quences

%soundsc (m)
%soundsc (Sk1)
%soundsc (Sk2)
% Apres l'ecoute attentive de m, de Sk1 et Sk2 on s'est rendu compte que
% nous avons s�par� les deux deux notes en fonctions distinctes. 






