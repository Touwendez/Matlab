function x = createnote(d,n_note,fs)
  if n_note == -1
    f_note = 0; % Si n_note = -1 -> freq = 0 -> signal a 0
  else 
    f_note = 440*2^((n_note-69)/12); % freq de la note
  end
  
  N = d * fs; % Nb echantillons
  n = 0:1:N-1;
  t = n/fs; % vecteur de tps
  x = sin(2*pi*f_note*t); % signal
end

  % Etude dans le domaine fr�quentiel
  